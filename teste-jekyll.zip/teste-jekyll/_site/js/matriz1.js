//Cria o array com os valores
var array = [null, 7, 14, 13, 11, 8, null, 12, 22, 18, 7, 9, null, 7, 6, 12, 14, 9, null, 7, 6, 8, 2, 10, null];
var dimensaoArray = '5x5';
var A1 = mountArray(array, dimensaoArray);
var elemArray = 4;
var condicoes = {
  fabrica1: 150,
  fabrica2: 150,
  valores: {
    1: 45,
    2: 30,
    3: 80,
    4: 40
  }
};
